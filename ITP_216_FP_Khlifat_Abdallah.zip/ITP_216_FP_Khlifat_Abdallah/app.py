from flask import Flask, redirect, render_template, request, session, url_for, send_file
import os
import io
import sqlite3 as sl
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.linear_model import LinearRegression
import numpy as np
import datetime

from sklearn.model_selection import train_test_split

# This is the application program

app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0         # This has to do with Cache, I'm not sure what exactly
db = "arab-economic-indicators.db"


@app.route("/")
def home():
    title = "Data Archive"
    return render_template("home.html", message=title, list_of_countries = db_get_countries(), list_of_indicators = db_get_indicators())


@app.route("/redirect_home", methods=["POST"])
def redirect_home():
    return redirect(url_for('home'))


@app.route("/submit_choices", methods=["POST"])
def submit_classification():
    session["country"] = request.form["country"]
    session["indicator"] = request.form["indicator"]                    # These are all collected from user
    session["initial_year"] = request.form["initial_year"]
    session["end_year"] = request.form["end_year"]


    if 'country' not in session or 'indicator' not in session:
        return redirect(url_for("home"))                                # This redirects to home if no session['category'] exists

    if int(session["initial_year"]) < 1980 or int(session["end_year"]) > 2022:
        return redirect(url_for("home"))                                # This redirects if dates are out of range

    if int(session["initial_year"]) >= int(session["end_year"]):
        return redirect(url_for("home"))                                # This redirects if end year is before initial year


    return redirect(url_for("data_presenter", country=session['country'], indicator=session['indicator'],
                            initial_year=session["initial_year"], end_year=session["end_year"]))


@app.route("/submit_classification/<country>/<indicator>/<initial_year>/<end_year>")
def data_presenter(country, indicator, initial_year, end_year):
    title = country + "'s " + indicator

    return render_template('plot.html', message=title, country=country, indicator=indicator, initial_year=initial_year, end_year=end_year)


@app.route("/fig/<country>/<indicator>/<initial_year>/<end_year>")
def fig(country, indicator, initial_year, end_year):
    fig = create_figure(country, indicator, initial_year, end_year)

    img = io.BytesIO()
    fig.savefig(img, format="png")
    img.seek(0)
    return send_file(img, mimetype="image/png")


@app.route("/submit_projection/<year>", methods=["POST"])
def data_projector():
    session['projection_year'] = request.form['year']
    y_pred = add_projection_to_df(country=session['country'], indicator=session['indicator'],
                           initial_year=session['initial_year'], end_year=session['end_year'])
    return render_template('plot.html', message="", country=session['country'], indicator=session['indicator'],
                           initial_year=session['initial_year'], end_year=session['end_year'])

def create_figure(country, indicator, initial_year, end_year):
    """
    This function plots a figure, given a data frame, by the following steps:
    1- call db_create_df() Then drop all empty data entries
    2- create a figure on matplotlib
    3- add super title to the figure, using plt.suptitle()
    4- set xticks
    5- add grid
    6- set x and y-axis labels, and labels for plots
    7- create a line of best fit, using the source you found on the net
    8- set color, size, and shape of data entries
    9- add legend
    :param country:
    :param indicator:
    :param initial_year:
    :param end_year:
    :return: fig
    """
    df = db_create_df(country, indicator, initial_year, end_year)

    n = 0
    for value in df['data']:
        if str(value) == '':
            df = df.drop(n)
        n += 1

    # Now data is cleaned from all empty spaces

    fig, ax = plt.subplots(layout='tight')

    plt.suptitle(country + "'s " + indicator)

    ax.scatter(x=df["year"], y=df["data"], label='scatter', color='#ef5d00', marker='x')

    ax.grid()
    ax.set(xlabel="Year", ylabel=indicator)


    # For some unkown reason I had to do this, but hey, it works!
    list_of_years = []
    for year in df['year']:
        list_of_years.append(int(year))

    list_of_values = []
    for value in df['data']:
        list_of_values.append(float(value))

    a, b = np.polyfit(list_of_years, list_of_values, 1)        # This is how to create a line of best fit

    ax.plot(df["year"], a*df["year"]+b, color='#77024f', linewidth=4, label='best fit')

    ax.legend()

    return fig


def db_create_df(country, indicator, initial_year, end_year):
    """
    This function will create a dataframe that will be used to plot a graph, by the following steps:
    1- connect to database and cursor
    2- write SQL statement that collects the row with a specific country and indicator
    3- execute using cursor and save the collected data to a variable
    4- now we have an iterator over this tuple: ('code', 'code', 'country', 'indicator', 'units', 'scale', 1980 data, 1981 data)
    5- create pandas dataframe
    6- get data, filtered by year
    7- add data to dataframe (after changing data to float())
    8- return dataframe
    :param country:
    :param indicator:
    :param initial_year:
    :param end_year:
    :return:    indexed dataframe with year and data entry columns
    """
    conn = sl.connect(db)
    curs = conn.cursor()

    country = '\'' + country + '\''
    indicator = '\'' + indicator + '\''     # These are to format the variables of the following statement according to SQL format

    stmt_row = \
        "SELECT * FROM dataset " \
       " WHERE Country = " + country + " " \
       " AND `Subject Descriptor` = " + indicator + ";"                # Don't forget the ``
    # This statement grabs an iterator over the row we need

    data_set = curs.execute(stmt_row)
    list_of_data = []

    for data in data_set:
        n = 6 + int(initial_year) - 1980                    # 6 first columns, then 1985 - 1980
        while n < len(data) - 2029 + int(end_year):
            if data[n] != 'n/a' and data[n] != '':
                list_of_data.append(float(data[n]))
            else: list_of_data.append('')
            n += 1
        break

    df = pd.DataFrame()
    df['year'] = range(int(initial_year), int(end_year) + 1 )     # size = end_year - initial_year + 1
    df['data'] = list_of_data

    return df


def add_projection_to_df(country, indicator, initial_year, end_year, projection_year):
    """
    NOTE: DUE TO THE SHORTAGE OF TIME, I'm copying most of whats below this from the CSV-DB file
    :param country:
    :param indicator:
    :param initial_year:
    :param end_year:
    :param projection_year:
    :return:
    """
    df = db_create_df(country, indicator, initial_year, end_year)

    df['year'] = pd.to_datetime(df['year']) \
        .map(datetime.datetime.toordinal).dropna()

    X_train, X_test, y_train, y_test = \
        train_test_split(df['year'], df['data'],
                         test_size=0.5, random_state=0)

    under_model = LinearRegression(fit_intercept=True, copy_X=True, n_jobs=2)
    under_model.fit(X_train, y_train)

    y_pred = under_model.predict(X_test)

    """This is incomplete, unfortunately"""

    return y_pred

def db_get_countries():
    """
    This function returns a list of countries from a database, by the following steps:
    1- connect to database and create cursor
    2- write a statement that calls all countries of the database
    3- execute statement and store it in a variable
    4- loop over the variable, and add all unique data to a list of countries
    5- return list of countries
    :return: list of countries
    """
    conn = sl.connect(db)
    curs = conn.cursor()

    stmt = "SELECT Country FROM dataset"
    data = curs.execute(stmt)

    list_of_countries = []
    for item in data:                           # NOTE: item is a tuple
        if item[0] not in list_of_countries:
            list_of_countries.append(item[0])   # item[0] to take the only value in the tuple

    return list_of_countries

    """ this function is Complete! """


def db_get_indicators():
    """
    This function returns a list of indicators from a database, by the following steps:
    1- connect to database and create cursor
    2- write a statement that calls all indicators of the database
    3- execute statement and store it in a variable
    4- loop over the variable, and add all unique data to a list of indicators
    5- return list of indicators
    FYI This is a copy paste of the function above
    :return: list of indicators
    """
    conn = sl.connect(db)
    curs = conn.cursor()

    stmt = "SELECT `Subject Descriptor` FROM dataset"            # Surrounded by a Grave accent because of space
    data = curs.execute(stmt)

    list_of_indicators = []
    for item in data:                                            # NOTE: item is a tuple
        if item[0] not in list_of_indicators:
            list_of_indicators.append(item[0])                   # item[0] to take the only value in the tuple

    return list_of_indicators

    """ this function is complete! """


def main():
    fig = create_figure('Iraq', 'Current account balance', '1985', '2015')

    #plt.show()

if __name__ == "__main__":
    app.secret_key = os.urandom(12)
    app.run(debug=True)
    pass