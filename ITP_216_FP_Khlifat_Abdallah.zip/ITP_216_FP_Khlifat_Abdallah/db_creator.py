# This file is a database creator
# It will convert a csv file into a db using SQL code

import sqlite3 as sl

file_path = 'csv/Final_Project_Data-csv.csv'
db = 'arab-economic-indicators.db'


def create(fn):
    """
    This function will be used to create the database used for my final project, by the following steps:
    1- open csv file
    2- read header line
    3- strip and split header line
        *Now header_list is complete*
    4- call conn and curs
    5- stmt1 = CREATE TABLE statement
    6- execute stmt1
    7- commit connection
    8- close cursor, connection, and file
    """
    f_in = open(fn, 'r')

    header = f_in.readline()
    header_list = header.strip().split(',')     # ['WEO Country Code', 'WEO Subject Code', 'Country', 'Subject Descriptor', \
                                                # 'Units', 'Scale', 'Country/Series-specific Notes', '1980', '1981', '1982',\
                                                # '1983', '1984', '1985', '1986', '1987', '1988', '1989', '1990', '1991',   \
                                                # '1992', '1993', '1994', '1995', '1996', '1997', '1998', '1999', '2000',   \
                                                # '2001', '2002', '2003', '2004', '2005', '2006', '2007', '2008', '2009',   \
                                                # '2010', '2011', '2012', '2013', '2014', '2015', '2016', '2017', '2018',   \
                                                # '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', '2027',   \
                                                # '2028', 'Estimates Start After']

                                                # NOTE: All headers are strings



    conn = sl.connect(db)
    curs = conn.cursor()

    stmt1 = "CREATE TABLE dataset " + str(tuple(header_list)) + ";"
    # SQL takes a tuple of values, and adds them to the header of the table

    curs.execute(stmt1)

    f_in.close()
    conn.commit()

    curs.close()
    conn.close()

    """ This function is complete! """


def store_data(table: str, fn):
    """
    This function will be used to load data into the table created earlier, by the following steps:
    1-  open csv file
    2-  create the header line, as done in the previous function
    3-  create a header list, as done in the previous function
    4-  create a list, which will store each individual list of data: list[list[]]
            NOTE: I faced a problem, some data entries have commas part of the string that shouldn't be split \
            This was solved by doing the following:

         I   - From the cvs file, I looked for all the data entries with a comma in them (using find)
         II  - Turns out that some of these entries are in the following csv form :  str,str,"STR WITH COMMA IN IT",str,str...
         III - So I split each line first by the character \" | I got the following list for some lines:
               ['str,str,str', 'str with comma', 'str,str,str,str...']
               Now I have some lines with length 1 that should be split by commas
               And some lines with length 3 that should be split by commas except for the 2nd entry, index 1.
         IV  - I went over all the quotation-split-lines, if their length is 3, I split all except the 2nd index and \
               added them to a final list. If their length is 1, I split and added to the final list
         V   - The result is a list with all data entries.
                 NOTE: len(header_list) = 56, so the length of the final_list that will be added to the list of rows should be 56
         VI  - Now, some final_lists have 56 entries in them (which is correct), others have 58 which need cleaning.
               So I looked for any mistakes in these length 58 lists, turns out they are at indexes 3 and 5 for some reason
               S0 I deleted indexes 3 and 5
         VII - Now, all final_lists have length 56, which is the length of the header_list, so I appended them to a \
               rows_list, which is a list of lists of entries parallel to the header_list
                     *NOW THE DATA CLEANSING PORTION IS COMPLETE, WE CONTINUE TO STORING THE DATA IN THE DATABASE*

    5-  close file :)
    6-  the final rows of the rows_list were empty, so I erased them by pop, I popped twice.
    7-  the length of the rows list is 231, so total data entries (excluding header) = 231*56 = 12936
    8-  call connection and cursor
    9-  create a for loop to generate SQL statements to be executed by cursor
    10- commit changes
    11- close connection and cursor
    """
    f_in = open(fn, 'r')

    header = f_in.readline()
    header_list = header.strip().split(',')         # len(header_list) = 56

    rows_list = []

    for line in f_in:
        quotation_formated_line = line.strip().split("\"")

        final_list = []
        if len(quotation_formated_line) == 3:      # THIS IS IF LENGTH == 3
            data_list1 = quotation_formated_line[0].strip().split(',')
            for data in data_list1:
                final_list.append(data)                                # This is the data from index 0

            final_list.append(quotation_formated_line[1])              # This is the data from index 1

            data_list2 = quotation_formated_line[2].strip().split(',')
            for data in data_list2:
                final_list.append(data)                                # This is the data from index 3

        else:                                      # THIS IS IF LENGTH == 1
            data_list = quotation_formated_line[0].strip().split(',')

            for data in data_list:
                final_list.append(data)

        if len(final_list) == 58:
            del final_list[3]
            del final_list[5]

        # Now each individual row is clean

        rows_list.append(final_list)
    # END OF FOR LOOP

    rows_list.pop()
    rows_list.pop()

    # NOW THE DATA IS CLEAN

    f_in.close()

    conn = sl.connect('arab-economic-indicators.db')
    curs = conn.cursor()

    for row in rows_list:
        stmt = " INSERT INTO " + table + " " + str(tuple(header_list)) + \
               " VALUES " + str(tuple(row)) + ";"

        curs.execute(stmt)

    conn.commit()       # FINALLY

    curs.close()
    conn.close()

    """ THIS FUNCTION IS COMPLETE! """


def main():
    # create(fn=file_path) # | The dataset only needs to be created once
    # store_data(table='dataset', fn=file_path)
    pass

""" THIS PROGRAM IS COMPLETE! """

if __name__ == "__main__":
    main()